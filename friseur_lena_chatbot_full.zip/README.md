# Friseur Lena Termin-Chatbot

Ein deutschsprachiger Chatbot zur Terminbuchung für Friseursalons.  
**Einfach auf Vercel deployen – keine Datenbank, kein Backend nötig.**

## Features

- Vollständiger Dialogflow (Name, Service, Datum)
- Weiterleitung zu Calendly (deutsche Sprache)
- Responsive Design mit Tailwind CSS
- Einfache Einbindung per Link oder iFrame

## Deployment (Vercel, ohne GitHub)

1. Gehe auf https://vercel.com/new
2. Wähle "Upload" und lade das komplette ZIP hoch
3. Deploy!
4. Dein Chatbot ist nach wenigen Minuten live

### Einbinden in Website

Nutze diesen Embed-Code:

<iframe src="DEIN-VERCEL-LINK" width="350" height="600" style="border-radius:16px;border:none;"></iframe>
