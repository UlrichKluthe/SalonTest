import { useState } from "react";

export default function Home() {
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [service, setService] = useState("");
  const [date, setDate] = useState("");

  const services = [
    "Haarschnitt",
    "Färben",
    "Styling",
    "Bartpflege",
    "Beratung"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 to-purple-200 flex items-center justify-center">
      <div className="max-w-md w-full rounded-2xl shadow-2xl bg-white p-6">
        <h2 className="text-2xl font-bold mb-4 text-purple-800">Friseur Lena Termin-Chatbot</h2>
        {step === 0 && (
          <>
            <p className="mb-4">Willkommen bei Friseur Lena! Ich helfe dir gerne bei deiner Terminbuchung. Wie darf ich dich ansprechen?</p>
            <input
              type="text"
              className="border p-2 w-full rounded-lg mb-4"
              placeholder="Dein Name"
              value={name}
              onChange={e => setName(e.target.value)}
            />
            <button
              className="bg-purple-600 text-white px-4 py-2 rounded-xl"
              disabled={!name}
              onClick={() => setStep(1)}
            >
              Weiter
            </button>
          </>
        )}

        {step === 1 && (
          <>
            <p className="mb-4">Welche Dienstleistung möchtest du buchen, {name}?</p>
            <select
              className="border p-2 w-full rounded-lg mb-4"
              value={service}
              onChange={e => setService(e.target.value)}
            >
              <option value="">Bitte wählen…</option>
              {services.map(s => (
                <option key={s}>{s}</option>
              ))}
            </select>
            <button
              className="bg-purple-600 text-white px-4 py-2 rounded-xl"
              disabled={!service}
              onClick={() => setStep(2)}
            >
              Weiter
            </button>
          </>
        )}

        {step === 2 && (
          <>
            <p className="mb-4">Wann möchtest du gern kommen?</p>
            <input
              type="date"
              className="border p-2 w-full rounded-lg mb-4"
              value={date}
              onChange={e => setDate(e.target.value)}
            />
            <button
              className="bg-purple-600 text-white px-4 py-2 rounded-xl"
              disabled={!date}
              onClick={() => setStep(3)}
            >
              Zusammenfassung
            </button>
          </>
        )}

        {step === 3 && (
          <>
            <p className="mb-2">Super, {name}! Hier ist deine Auswahl:</p>
            <ul className="mb-4">
              <li><b>Service:</b> {service}</li>
              <li><b>Wunschtermin:</b> {date}</li>
            </ul>
            <a
              href="https://calendly.com/ulrich-luthe?locale=de"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-green-600 text-white px-4 py-2 rounded-xl mb-2 block text-center"
            >
              Termin jetzt buchen
            </a>
            <button
              className="mt-2 text-purple-700 underline"
              onClick={() => setStep(0)}
            >
              Neue Buchung starten
            </button>
          </>
        )}
      </div>
    </div>
  );
}
