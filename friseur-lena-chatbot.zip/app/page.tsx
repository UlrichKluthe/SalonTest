"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"

export default function FriseurChatbot() {
  const [step, setStep] = useState(0)
  const [name, setName] = useState("")
  const [service, setService] = useState("")
  const [date, setDate] = useState("")

  const services = ["Haarschnitt", "Färben", "Styling", "Bartpflege", "Beratung"]

  const resetForm = () => {
    setStep(0)
    setName("")
    setService("")
    setDate("")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 to-purple-200 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-purple-800">Friseur Lena Termin-Chatbot</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {step === 0 && (
            <div className="space-y-4">
              <p className="text-gray-700">
                Willkommen bei Friseur Lena! Ich helfe dir gerne bei deiner Terminbuchung. Wie darf ich dich ansprechen?
              </p>
              <div className="space-y-2">
                <Label htmlFor="name">Dein Name</Label>
                <Input
                  id="name"
                  type="text"
                  placeholder="Dein Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
              <Button
                className="w-full bg-purple-600 hover:bg-purple-700"
                disabled={!name.trim()}
                onClick={() => setStep(1)}
              >
                Weiter
              </Button>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-4">
              <p className="text-gray-700">Welche Dienstleistung möchtest du buchen, {name}?</p>
              <div className="space-y-2">
                <Label htmlFor="service">Dienstleistung</Label>
                <Select value={service} onValueChange={setService}>
                  <SelectTrigger>
                    <SelectValue placeholder="Bitte wählen..." />
                  </SelectTrigger>
                  <SelectContent>
                    {services.map((s) => (
                      <SelectItem key={s} value={s}>
                        {s}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button
                className="w-full bg-purple-600 hover:bg-purple-700"
                disabled={!service}
                onClick={() => setStep(2)}
              >
                Weiter
              </Button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              <p className="text-gray-700">Wann möchtest du gern kommen?</p>
              <div className="space-y-2">
                <Label htmlFor="date">Wunschtermin</Label>
                <Input
                  id="date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  min={new Date().toISOString().split("T")[0]}
                />
              </div>
              <Button className="w-full bg-purple-600 hover:bg-purple-700" disabled={!date} onClick={() => setStep(3)}>
                Zusammenfassung
              </Button>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              <p className="text-gray-700 font-medium">Super, {name}! Hier ist deine Auswahl:</p>
              <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                <div>
                  <span className="font-semibold">Service:</span> {service}
                </div>
                <div>
                  <span className="font-semibold">Wunschtermin:</span> {new Date(date).toLocaleDateString("de-DE")}
                </div>
              </div>
              <Button asChild className="w-full bg-green-600 hover:bg-green-700 mb-2">
                <a href="https://calendly.com/ulrich-luthe" target="_blank" rel="noopener noreferrer">
                  Termin jetzt buchen
                </a>
              </Button>
              <Button
                variant="outline"
                className="w-full text-purple-700 border-purple-700 hover:bg-purple-50"
                onClick={resetForm}
              >
                Neue Buchung starten
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
