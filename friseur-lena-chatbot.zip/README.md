# Friseur Lena Termin-Chatbot

Ein interaktiver Chatbot für die Terminbuchung bei Friseur Lena.

## Features

- Schritt-für-Schritt Terminbuchung
- Integration mit Calendly
- Responsive Design für alle Geräte
- Deutsche Benutzeroberfläche

## Deployment auf Vercel

1. Lade das Projekt als ZIP hoch oder verbinde es mit einem Git-Repository
2. Vercel erkennt automatisch Next.js
3. Klicke auf "Deploy"
4. Fertig!

## Einbettung in Website

\`\`\`html
<iframe 
  src="DEINE-VERCEL-URL" 
  width="350" 
  height="600" 
  style="border-radius:16px;border:none;">
</iframe>
\`\`\`

## Anpassungen

- Calendly-Link in `app/page.tsx` ändern
- Services in der `services` Array anpassen
- Farben und Styling in `app/globals.css` modifizieren
